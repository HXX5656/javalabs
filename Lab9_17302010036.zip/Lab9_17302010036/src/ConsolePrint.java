public interface ConsolePrint {
    public abstract void printShape();
}
